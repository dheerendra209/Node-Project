const express = require("express");
const bodyParser = require('body-parser');
const { body, validationResult } = require('express-validator');
const { urlencoded } = require("body-parser");


const app = express();
app.use(express.static('public'));
app.set('view engine', 'twig')
app.set('views', './website/views');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());


app.get('/', (req,res)=>{
    
    res.render('login',{});
    });

    app.post('/login1',  function(req,res){

        res.send('Welcome'+ req.body.username)
    });

app.post('/', [body('username', 'Username didn,t match').isEmail(),
     body('password', 'Invalid Password').isLength({ min: 5 })         
] ,(req,res)=>{
    const errors = validationResult(req);
    console.log(errors.mapped());

    if(!errors.isEmpty()){
        res.render('login',{title:"", error:errors.mapped()});

    }
    else{
        res.render('login1',{title:"User Data", username:req.body.username, password:req.body.password});
    }
            });
app.listen(3000,()=>console.log("Server is running"));