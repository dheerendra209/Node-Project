const express = require("express");
const bodyParser = require('body-parser')
const app = express();
app.use(express.static('public'));
app.set('view engine', 'twig')
app.set('views', './website/views');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());


app.get('/', (req,res)=>{
    
    res.render('ticket',{});
    });

app.post('/ticket1', (req,res)=>{
    
        res.render('ticket1',{title:"User details", name:req.body.name, email:req.body.email, select:req.body.select, gender:req.body.gender});
        });


app.listen(3000,()=>console.log("Server is running"));