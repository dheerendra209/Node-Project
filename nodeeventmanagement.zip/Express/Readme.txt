1.Fisrt you should write final.html file code on visual studio
2.Write main.js code on visaul studio
3.use visual studio terminal to run this code use command: "node main.js"
4.By these step you can you your html page on server.
5.Now write tem.js, ticket.twig, twicket1.twig, tem1.js, login.twig and login1.twig on visual studio seprately
6.Run one by one through studio terminal using these commands:
1) node tem.js
2) node tem1.js
7.Above code will show you validation in login page and data redirecting on another page.
