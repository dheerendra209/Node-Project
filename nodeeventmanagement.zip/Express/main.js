const express = require("express");
const app = express();
app.use(express.static('public'));
app.get("/", (req,res)=>{
res.sendFile(__dirname + '/website/final.html');
});

app.get("/form", (req,res)=>{
    res.sendFile(__dirname + '/website/form.html');
    });

app.get("/login", (req,res)=>{
        res.sendFile(__dirname + '/website/login.html');
        });

app.post("/users/profile",(req, res) => {
    res.send("Users profile data accessed");  
});

app.listen(3000,()=>console.log("Server is running"));